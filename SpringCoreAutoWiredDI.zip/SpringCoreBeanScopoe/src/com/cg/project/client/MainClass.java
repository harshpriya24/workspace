package com.cg.project.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.project.beans.Employee;

public class MainClass {

	public static void main(String[] args) {
	
		ApplicationContext context=new ClassPathXmlApplicationContext("projectBeans.xml");
		Employee employee=(Employee) context.getBean("employee");
		Employee employee2=(Employee) context.getBean("employee");
		if(employee==employee2)
			System.out.println("same reference");
		else
			System.out.println("not same reference");
		
		if(employee.equals(employee2))
			   System.out.println("same data");
		else
			System.out.println("not same reference");
	}
}


