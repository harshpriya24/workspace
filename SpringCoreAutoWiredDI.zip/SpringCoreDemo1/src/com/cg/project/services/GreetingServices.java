package com.cg.project.services;

public interface GreetingServices {
 void greetUser(String name);
}
