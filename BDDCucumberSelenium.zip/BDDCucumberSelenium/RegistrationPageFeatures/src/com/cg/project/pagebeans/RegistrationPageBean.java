package com.cg.project.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegistrationPageBean {
@FindBy(how=How.NAME,name="userid")
	private WebElement userId;
@FindBy(how=How.NAME,name="passid")
private WebElement password;
@FindBy(how=How.NAME,name="submit")
private WebElement submitBtn;
@FindBy(how=How.NAME,name="username")
	private WebElement userName;
@FindBy(how=How.NAME,name="address")
	private WebElement address;

@FindBy(how=How.NAME,name="country")
	private WebElement country;

@FindBy(how=How.NAME,name="zip")
	private WebElement zipCode;

@FindBy(how=How.NAME,name="email")
	private WebElement email;

@FindBy(how=How.NAME,name="sex")
	private WebElement gender;

public String getUserId() {
	return userId.getAttribute("value");
}

public void setUserId(String userId) {
	this.userId.sendKeys(userId);
}

public String getPassword() {
	return password.getAttribute("value");
}

public void setPassword(WebElement password) {
	this.password = password;
}

public WebElement getSubmitBtn() {
	return submitBtn;
}

public String getUserName() {
	return userName.getAttribute("value");
}

public void setUserName(String userName) {
	this.userName.sendKeys(userName);
}

public String getAddress() {
	return address.getAttribute("value");
}

public void setAddress(String address) {
	this.address.sendKeys(address);
}

public WebElement getCountry() {
	return country;
}

public void setCountry(WebElement country) {
	this.country = country;
}

public WebElement getZipCode() {
	return zipCode;
}

public void setZipCode(WebElement zipCode) {
	this.zipCode = zipCode;
}

public WebElement getEmail() {
	return email;
}

public void setEmail(WebElement email) {
	this.email = email;
}

public WebElement getGender() {
	return gender;
}

public void setGender(WebElement gender) {
	this.gender = gender;
}

}
