package com.cg.projecttest.stepdefinitions;

public class GithubLoginStepDefinition2 {

}
