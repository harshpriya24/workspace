package com.cg.projecttest.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.projecttest.pagebeans.LoginPage;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GithubStepDefiniton {
	private LoginPage loginpage;
	private WebDriver driver;
	@Before
	public void setUpEnv() {
		System.setProperty("webdriver.chrome.driver", "D:\\software backup\\chromedriver.exe");
	}

	@Given("^user is on githublogin page$")
	public void user_is_on_githublogin_page() throws Throwable {
        driver=new ChromeDriver();
        driver.get("https://github.com/login/");
        loginpage=PageFactory.initElements(driver,LoginPage.class);
	}

	@When("^userid and password is wrong$")
	public void userid_and_password_is_wrong() throws Throwable {
		loginpage.setUsername("harsh");
		loginpage.setPassword("priya");
		loginpage.clickSignIn();

	}

	@Then("^Incorrect username or password message should display$")
	public void incorrect_username_or_password_message_should_display() throws Throwable {
		String expectedErrorMessage="Incorrect username or password";
		Assert.assertEquals(expectedErrorMessage, loginpage.getActualErrorMessage());
	}

	@When("^userid and password is valid$")
	public void userid_and_password_is_valid() throws Throwable {
		loginpage.setUsername("harshpriya24@gmail.com");
		loginpage.setPassword("harshpriy@24");
		loginpage.clickSignIn();
	}

	@Then("^user should successfully sigin on github$")
	public void user_should_successfully_sigin_on_github() throws Throwable {
              String actualTitle=driver.getTitle();
              String expectedTitle="GitHub";
              Assert.assertEquals(expectedTitle, actualTitle);
	}
@After
public void tearDownSetup() {
	driver.close();
}
}
