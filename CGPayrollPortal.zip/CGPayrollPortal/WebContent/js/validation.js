function validateLoginForm(){
	
	if(document.loginForm.associateId.value==""){
		alert("enter AssociateId");
		return false;
	}
	else if(loginForm.password.value==""){
		alert("enter password");
		return false;
	}
}
function validateRegistrationForm() {
	if(registerForm.firstName.value==""){
		alert("enter first name");
		return false;
	}
	else if(registerForm.lastName.value==""){
		alert("enter last name");
		return false;
	}
	else if(registerForm.emailId.value==""){
		alert("enter email id");
		return false;
	}
	else if(registerForm.department.value==""){
		alert("enter department");
		return false;
	}
	else if(registerForm.designation.value==""){
		alert("enter designation");
		return false;
	}
	else if(registerForm.pancard.value==""){
		alert("enter pancard");
		return false;
	}
	else if(registerForm.yearlyInvestmentUnder80C.value==""){
		alert("enter yearlyInvestmentUnder80C");
		return false;
	}
	else if(registerForm.basicSalary.value==""){
		alert("enter basicSalary");
		return false;
	}
	else if(registerForm.epf.value==""){
		alert("enter epf");
		return false;
	}
	else if(registerForm.companyPf.value==""){
		alert("enter companyPf");
		return false;
	}
	else if(registerForm.bankName.value==""){
		alert("enter bankName");
		return false;
	}
	else if(registerForm.accountNo.value==""){
		alert("enter accountNo");
		return false;
	}
	else if(registerForm.ifscCode.value==""){
		alert("enter ifscCode");
		return false;
	}
}

function validatePassword(){
	if(changePasswordFrm.password.value.length>=6){
		if(changePasswordFrm.password.value.search(/[0-9]/)!=-1 && 
				changePasswordFrm.password.value.search(/[A-Z]/)!=-1 &&
				changePasswordFrm.password.value.search(/[!@#$%^&*()_+]/)!=-1){
			return true;
		}
		else{
			alert("password must contain atleast 1 number 1 uppercase letter and 1 special character");
		return false;
		}
	}
	else{
		alert("minimum of 6 characters");
		return false;
	}
}

function checkSame() {
	if(changePasswordFrm.password.value!=changePasswordFrm.confirmPassword.value){
		alert("password and confirm password didnot match");
		return false;
	}
}











