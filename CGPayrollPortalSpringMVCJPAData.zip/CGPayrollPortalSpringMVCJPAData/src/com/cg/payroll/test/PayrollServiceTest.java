/*package com.cg.payroll.test;
import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.PayrollDBUtil;

public class PayrollServiceTest {
	private static PayrollServices services;
	@BeforeClass
	public static void setUpTestEnv() {
		services=new PayrollServicesImpl();
	}
	@Before
	public void setUpTestData() {
	Associate associate1=new Associate(101,78000,"Saiyam", "Lunia", "IT", "Analyst", "AGHGSJD", 
			"s.lunia59@gmail.com", new Salary(35000, 1800, 1800), new BankDetails(11111, "CITI", "CITI00001"));
	Associate associate2=new Associate(102,80000,"Swastik", "Bhatt", "Training", "Manager", "FJFGJJJ", 
			"swastik@gmail.com", new Salary(35000, 1500, 1500), new BankDetails(11111, "CITI", "CITI00001"));
	PayrollDBUtil.associates.put(associate1.getAssociateId(), associate1);
	PayrollDBUtil.associates.put(associate2.getAssociateId(), associate2);
	
	PayrollDBUtil.ASSOCIATE_ID_COUNTER=102;
	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testGetAssociateDetailsForInvalidAssociateId()throws AssociateDetailsNotFoundException {
		services.getAssociateDetails(12345);
	}
	@Test
	public void testGetAssociateDetailsForValidAssociateId() throws AssociateDetailsNotFoundException{
		Associate expectedAssociate=new Associate(101,78000,"Saiyam", "Lunia", "IT", "Analyst", "AGHGSJD", 
				"s.lunia59@gmail.com", new Salary(35000, 1800, 1800), new BankDetails(11111, "CITI", "CITI00001"));
		Associate actualAssociate=services.getAssociateDetails(101);
		Assert.assertEquals(expectedAssociate, actualAssociate);
	}
	@Test
	public void testAcceptAssociateDetailsForValidData() {
		int expectedId=103;
		int actualId=services.acceptAssociateDetails("Saiyam", "Lunia", "slunia59@gmail.com", "Training", "Senior", "GDJHDJ", 80000, 35000, 1800, 1800, 11111, "CITI", "CITI10001");
		Assert.assertEquals(expectedId, actualId);
	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testCalculateNetSalaryForInvalidAssociateId() throws AssociateDetailsNotFoundException {
		services.calculateNetSalary(1434);
	}
	@Test
	public void testCalculateNetSalaryForValidAssociateId() throws AssociateDetailsNotFoundException {
		int expectedNetSalary=894000;
		int actualNetSalary=(int) services.calculateNetSalary(102);
		Assert.assertEquals(expectedNetSalary, actualNetSalary);
	}
	@Test
	public void testGetAllAssociateDetails() {
		Associate associate1=new Associate(101,78000,"Saiyam", "Lunia", "IT", "Analyst", "AGHGSJD", 
				"s.lunia59@gmail.com", new Salary(35000, 1800, 1800), new BankDetails(11111, "CITI", "CITI00001"));
		Associate associate2=new Associate(102,80000,"Swastik", "Bhatt", "Training", "Manager", "FJFGJJJ", 
				"swastik@gmail.com", new Salary(35000, 1500, 1500), new BankDetails(11111, "CITI", "CITI00001"));
		
		ArrayList<Associate> expectedAssociateList=new ArrayList<Associate>();
		expectedAssociateList.add(associate1);
		expectedAssociateList.add(associate2);
		ArrayList<Associate>actualAssociateList=(ArrayList<Associate>) services.getAllAssociateDetails();
		Assert.assertEquals(expectedAssociateList, actualAssociateList);
	}
	@After
	public void tearDownTestData() {
		PayrollDBUtil.associates.clear();
		PayrollDBUtil.ASSOCIATE_ID_COUNTER=100;
	}
	@AfterClass
	public static void tearDownTestEnv() {
		services=null;
	}
}*/
