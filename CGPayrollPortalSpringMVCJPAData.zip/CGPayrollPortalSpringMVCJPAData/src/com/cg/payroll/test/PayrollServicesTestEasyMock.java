package com.cg.payroll.test;

public class PayrollServicesTestEasyMock {
//	private static PayrollServices payrollServices;
//	private static AssociateDAO mockAssociateDao;
//	@BeforeClass
//	public static void setUpTestEnv() {
//		mockAssociateDao=EasyMock.mock(AssociateDAO.class);
//		payrollServices=new PayrollServicesImpl(mockAssociateDao);
//	}
//	@Before
//	public void setUpTestMockData() {
//		Associate associate1=new Associate(101,78000,"Saiyam", "Lunia", "IT", "Analyst", "AGHGSJD", 
//				"s.lunia59@gmail.com", new Salary(35000, 1800, 1800), new BankDetails(11111, "CITI", "CITI00001"));
//		Associate associate2=new Associate(102,80000,"Swastik", "Bhatt", "Training", "Manager", "FJFGJJJ", 
//				"swastik@gmail.com", new Salary(35000, 1500, 1500), new BankDetails(22222, "CITI", "CITI00001"));
//		Associate associate3=new Associate(85000,"Roshan", "Jha", "ADC", "Trainee", "GHGJHJJ", 
//				"roshan@gmail.com", new Salary(25000, 1400, 1400), new BankDetails(125665, "HDFC", "HDFC00009"));
//		ArrayList<Associate> associateList=new ArrayList<>();
//		associateList.add(associate1);
//		associateList.add(associate2);
//
//		EasyMock.expect(mockAssociateDao.save(associate3)).andReturn(associate3);
//
//		EasyMock.expect(mockAssociateDao.findOne(101)).andReturn(associate1);
//		EasyMock.expect(mockAssociateDao.findOne(102)).andReturn(associate2);
//		EasyMock.expect(mockAssociateDao.findOne(1234)).andReturn(null);
//		EasyMock.expect(mockAssociateDao.findAll()).andReturn(associateList);
//		EasyMock.replay(mockAssociateDao);
//
//	}
//	@Test(expected=AssociateDetailsNotFoundException.class)
//	public void testGetAssociateDataForInvalidAssociateId() throws AssociateDetailsNotFoundException{
//		payrollServices.getAssociateDetails(1234);
//		EasyMock.verify(mockAssociateDao.findOne(1234));
//	}
//	@Test
//	public void testGetAssociateDataForValidAssociateId() throws AssociateDetailsNotFoundException{
//		Associate expectedAssociate=new Associate(102,80000,"Swastik", "Bhatt", "Training", "Manager", "FJFGJJJ", 
//				"swastik@gmail.com", new Salary(35000, 1500, 1500), new BankDetails(22222, "CITI", "CITI00001"));
//		Associate actualAssociate=payrollServices.getAssociateDetails(102);
//		assertEquals(expectedAssociate, actualAssociate);
//		EasyMock.verify(mockAssociateDao.findOne(102));
//	}
//	@After
//	public void tearDownTestMockData() {
//		EasyMock.resetToDefault(mockAssociateDao);
//	}
//	@AfterClass
//	public static void tearDownTestEnv() {
//		mockAssociateDao=null;
//		payrollServices=null;
//	}
}











